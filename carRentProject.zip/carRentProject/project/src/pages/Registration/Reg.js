import React, { useState } from 'react'
import {FormGroup,FormControl,Input,InputLabel,Button } from "@mui/material"
import '../Registration/Reg.css';
import axios from 'axios';


const Reg = () => {


const adduserData=async(event)=>{
    alert(222)
    event.preventDefault()
    

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const contact = document.getElementById("phone").value;
    const pass = document.getElementById("pass").value;


    // console.log(MenuName, price);

    const object = { Name: name, Email: email, Contact:contact,Password:pass }
    console.log(object);
    try {
        const obj = await axios.post("http://localhost:5000/postreg", object)
        console.log(obj.data)
        
    }
    catch (err) {
        console.log(err)
    }

      
      
    }
    

return (
    <div className='centerForm'>
    <div style={{border:"1px solid black",padding:20,width:"50%"}}>
        <h4 style={{textAlign:'start'}}>User Registration</h4>
        <hr></hr>
        <FormGroup>
            <div style={{marginBottom : 20,marginTop:0}}>
                <div style={{width:"100%"}}>
                <FormControl  style={{width:"90%"}}>
                    <InputLabel >Name</InputLabel >
                    <Input name='name' id='name'></Input>
                </FormControl>
                </div>
            </div>
                <div style={{width:"100%",marginBottom : 20}}>
                <FormControl  style={{width:"90%"}}>
                    <InputLabel >Email</InputLabel >
                    <Input name='email' id='email'></Input>

                </FormControl>
                </div>
                <div style={{width:"100%"}}>
                <FormControl  style={{width:"90%",marginBottom : 20}}>
                    <InputLabel >Phone</InputLabel >
                    <Input name='phone' id='phone'></Input>

                </FormControl>
                </div>
                <div style={{width:"100%",marginBottom : 20}}>
                <FormControl  style={{width:"90%"}}>
                    <InputLabel >Password</InputLabel >
                    <Input type='password' name='password' id='pass'></Input>

                </FormControl>
                </div>
            <Button style={{margin:20,backgroundColor:"blue",color:'#fff'}} type="submit" onClick={adduserData}>Submit</Button>
            
        </FormGroup>
    </div>
    </div>
  )
}

export default Reg