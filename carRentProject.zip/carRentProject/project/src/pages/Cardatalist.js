import React, { useEffect, useState } from 'react'
import carData from '../assets/data/carData';

import {
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
  MDBCardImage,

} from 'mdb-react-ui-kit';
import { Link } from 'react-router-dom';
function Cardatalist() {
  const [car, setCar] = useState([]);



  const fetchData = async () => {
    const result = await fetch("http://localhost:5000/getcar")
    const response = await result.json();
    setCar(response)

  }

  useEffect(() => {
    fetchData()
  }, [])


  return (
    <div style={{ display: "flex" }}>


      {
        car.map((item) => {
          return (
            <div className='container mt-5'>


              <MDBCard>

                <MDBCardBody>

                  <MDBCardTitle>Brand:{item.brand}</MDBCardTitle>
                  <MDBCardImage src={item.imgUrl} position='top' alt='...' />
                  <MDBCardTitle>Car Name{item.carName}</MDBCardTitle>
                  <MDBCardText>Model: {item.model}</MDBCardText>
                  <MDBCardText>$: {item.price}</MDBCardText>
                  <MDBCardText>Speed: {item.speed}</MDBCardText>
                  <MDBCardText>GPS: {item.gps}</MDBCardText>
                  <MDBCardText>Seat Type: {item.seatType}</MDBCardText>
                  <MDBCardText>Automatic: {item.automatic}</MDBCardText>
                  <MDBCardText>Description: {item.description}</MDBCardText>

                  <Link to='/bookingform'>
                  <button className='btn btn-primary'>Book Car</button>
                  
                  </Link>

                </MDBCardBody>
              </MDBCard>


            </div>
          );
        }

        )
      }
    </div>

  )
}

export default Cardatalist