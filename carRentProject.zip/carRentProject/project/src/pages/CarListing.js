import React from "react";
import { Container, Row } from "reactstrap";

import Cardatalist from "./Cardatalist";
const CarListing = () => {
  return (
    <div title="Cars">

      <section>
        <Container>
          <Row>

            <Cardatalist />

          </Row>
        </Container>
      </section>
    </div>
  );
};

export default CarListing;