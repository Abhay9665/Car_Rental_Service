import React, { useState } from "react";
import { Form, FormGroup } from "reactstrap";
import "../../src/styles/booking-form.css";
import axios from "axios";
const AddCarForm = () => {

  // const [success,setSuccess]=useState(false)




  const addData=async(event)=>{
    alert(222)
    event.preventDefault()
    

    const brand = document.getElementById("brand").value;
    const rating = document.getElementById("rating").value;
    const carName = document.getElementById("carName").value;
    const img = document.getElementById("img").value;
    const model = document.getElementById("model").value;
    const price = document.getElementById("price").value;
    const speed = document.getElementById("speed").value;
    const gps = document.getElementById("gps").value;
    const seatType = document.getElementById("seatType").value;
    const automatic = document.getElementById("automatic").value;
    const description = document.getElementById("description").value;





    // console.log(MenuName, price);

    const object = { brand: brand, rating: rating, carName:carName,imgUrl:img,model:model,price:price,speed:speed,gps:gps,seatType:seatType,auto:automatic,decription:description  }
    console.log(object);
    try {
        const obj = await axios.post("http://localhost:5000/postcar", object)
        console.log(obj.data)
        // setSuccess(true)
    }
    catch (err) {
        console.log(err)
    }

      
      
    }



  


  return (
    <div className="container " style={{padding:"120px"}}>

      <Form>
        <FormGroup className="booking__form d-inline-block me-4 mb-4">
          <input
            type="text"
            placeholder="Brand"
            id="brand"
          />
        </FormGroup>
        <FormGroup className="booking__form d-inline-block ms-1 mb-4">
          <input
            type="number"
            placeholder="Rating"
            id="rating"
          />
        </FormGroup>

        <FormGroup className="booking__form d-inline-block me-4 mb-4">
          <input
            type="text"
            placeholder="Car Name"
            id="carName"
          />
        </FormGroup>
        <FormGroup className="booking__form d-inline-block ms-1 mb-4">
          <input
            type="file"
            placeholder="Insert Image"
            id="img"
          />
        </FormGroup>

        <FormGroup className="booking__form d-inline-block me-4 mb-4">
          <input
            type="text"
            placeholder="Model"
           id="model"
          />
        </FormGroup>
        <FormGroup className="booking__form d-inline-block ms-1 mb-4">
          <input
            type="number"
            placeholder="Price"
            id="price"
          />
        </FormGroup>

        <FormGroup className="booking__form d-inline-block me-4 mb-4">
          <input
            type="text"
            placeholder="Speed"
            id="speed"
          />
        </FormGroup>
        <FormGroup className="booking__form d-inline-block ms-1 mb-4">
          <input
            type="text"
            placeholder="gps"
            //   className="time__picker"
           id="gps"
          />
        </FormGroup>

        <FormGroup className="booking__form d-inline-block me-4 mb-4">
          <input
            type="text"
            placeholder="Seat Type"
           id="seatType"
          />
        </FormGroup>

        <FormGroup className="booking__form d-inline-block me-4 mb-4">
          <input
            type="text"
            placeholder="Automatic"
            id="automatic"
          />
        </FormGroup>

        <FormGroup>
          <textarea
            rows={5}
            type="textarea"
            className="textarea"
            placeholder="description"
            id="description"
            value="Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum voluptatum repellat quod accusamus incidunt vero ratione iure nam reiciendis architecto, tenetur molestiae maiores aliquam amet et voluptate! Quas incidunt facilis, maiores repellendus voluptate ullam dicta sit error aspernatur ad non enim vero hic tenetur? Natus, eaque. id vitae, non ullam saepe possimus."
          ></textarea>
        </FormGroup>

        <div className="payment text-end mt-5">
          <input
            type="submit"
            className="btn btn-primary"
            value="Add Car"
            onClick={addData}
          />

        </div>
        {/* {
        success ?   <div class="alert alert-success">
        <strong>Success!</strong> Your Data SuccessFully Submited
      </div> : ""
      } */}
      </Form>
    </div>
  );
};

export default AddCarForm;
