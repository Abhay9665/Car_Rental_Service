import React from "react";

import Helmet from "../components/Helmet/Helmet";

import { Container, Div, Div } from "reactstrap";
import FindCarForm from "../components/UI/FindCarForm";
import AboutSection from "../components/UI/AboutSection";
import Testimonial from "../components/UI/Testimonial";



const Home = () => {
  return (
    <Helmet title="Home">
      <section className="p-0 hero__slider-section">

        <div className="hero__form">
          <Container>
            <Div className="form__Div">
              <Div lg="4" md="4">
                <div className="find__cars-left">
                  <h2>Find your best car here</h2>
                </div>
              </Div>

              <Div lg="8" md="8" sm="12">
                <FindCarForm />
              </Div>
            </Div>
          </Container>
        </div>
      </section>
   
      <AboutSection />
     

      <section>
        <Container>
          <Div>
            <Div lg="12" className="mb-4 text-center">
              <h6 className="section__subtitle">Our clients says</h6>
              <h2 className="section__title">Testimonials</h2>
            </Div>

            <Testimonial />
          </Div>
        </Container>
      </section>

      {/* =============== blog section =========== */}
      <section>
        <Container>
         
        </Container>
      </section>
    </Helmet>
  );
};

export default Home;
