import React, { useState } from "react";
import "../../styles/booking-form.css";

const BookingForm = () => {
  const [fname, setFname]=useState()
  const [lname, setLname]=useState()
  const [email, setEmail]=useState()
  const [number, setNumber]=useState()
  const [faddress, setFaddress]=useState()
  const [taddress, setTaddress]=useState()
  const [person, setPerson]=useState()
  const [air, setAir]=useState()
  const [date, setDate]=useState()
  const [time, setTime]=useState()
  const [textarea, setTextarea]=useState()

  


  const submitHandler = (event) => {
    event.preventDefault();
  };


    const getData=(e)=>{
      alert(111)
      



    }


  return (
    <Form onSubmit={submitHandler}>
      <Div className="booking__form d-inline-block me-4 mb-4">
        <input type="text" placeholder="First Name" onChange={(e)=>setFname(e.target.value)}/>
      </Div>
      <Div className="booking__form d-inline-block ms-1 mb-4">
        <input type="text" placeholder="Last Name" onChange={(e)=>setLname(e.target.value)} />
      </Div>

      <Div className="booking__form d-inline-block me-4 mb-4">
        <input type="email" placeholder="Email" onChange={(e)=>setEmail(e.target.value)}/>
      </Div>
      <Div className="booking__form d-inline-block ms-1 mb-4">
        <input type="number" placeholder="Phone Number" onChange={(e)=>setNumber(e.target.value)}/>
      </Div>

      <Div className="booking__form d-inline-block me-4 mb-4">
        <input type="text" placeholder="From Address" onChange={(e)=>setFaddress(e.target.value)}/>
      </Div>
      <Div className="booking__form d-inline-block ms-1 mb-4">
        <input type="text" placeholder="To Address" onChange={(e)=>setTaddress(e.target.value)}/>
      </Div>

      <Div className="booking__form d-inline-block me-4 mb-4">
        <select name="" id="" onChange={(e)=>setPerson(e.target.value)}>
          <option value="1 person">1 Person</option>
          <option value="2 person">2 Person</option>
          <option value="3 person">3 Person</option>
          <option value="4 person">4 Person</option>
          <option value="5+ person">5+ Person</option>
        </select>
      </Div>
      <Div className="booking__form d-inline-block ms-1 mb-4">
        <select name="" id="" onChange={(e)=>setAir(e.target.value)}>
          <option value="1 luggage">AC</option>
          <option value="2 luggage">Non AC</option>

        </select>
      </Div>

      <Div className="booking__form d-inline-block me-4 mb-4">
        <input type="date" placeholder="Journey Date" onChange={(e)=>setDate(e.target.value)}/>
      </Div>
      <Div className="booking__form d-inline-block ms-1 mb-4">
        <input
          type="time"
          placeholder="Journey Time"
          className="time__picker"
          onChange={(e)=>setTime(e.target.value)}
        />
      </Div>

      <Div>
        <textarea
          rows={5}
          type="textarea"
          className="textarea"
          placeholder="Write"
          onChange={(e)=>setTextarea(e.target.value)}
        ></textarea>
      </Div>

      <div className="payment text-end mt-5">
        <button type="button">Book Now</button>
      </div>
    </Form>
  );
};

export default BookingForm;
