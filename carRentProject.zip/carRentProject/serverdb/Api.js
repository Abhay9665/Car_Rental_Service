
const Express = require("express")
const con = require("./server");
const app = Express();
const cors = require('cors')
app.use(cors());

// ************User Registration Get Data**********************
app.get("/getuser",(req,resp)=>{
    con.query('select * from userReg',(error,result)=>{
        if(error)
            console.log("Error is "+error);
        else
            resp.send(result);
    });
});
const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/postreg', (req, res) => {
    const Id = req.body.Id
    const Name = req.body.Name;
    const Email = req.body.Email;
    const Contact = req.body.Contact;
    const Password = req.body.Password;

    con.query('insert into userReg values(?,?,?,?,?)', [Id,Name, Email, Contact, Password], (err, result) => {
      if (err) {
        console.log(err);
      } else {
        res.send(result);
      }
    })
  })

//get api for add car

app.get("/getcar",(req,resp)=>{
    con.query('select * from addCar',(error,result)=>{
        if(error)
            console.log("Error is "+error);
        else
            resp.send(result);
    }); 
});



  //post api for add car
  app.post('/postcar', (req, res) => {
    // const id = req.body.id;
    // const brand = req.body.brand;
    // const rating = req.body.rating;
    // const carName = req.body.carName;
    // const imgUrl = req.body.imgUrl;
    // const model = req.body.model;
    // const price = req.body.price;

    // const speed = req.body.speed;

    // const gps = req.body.gps;
    // const seatType = req.body.seatType;
    // const auto = req.body.auto;
    // const decription = req.body.decription;
    const data=req.body;



    con.query('insert into addcar set ?',[data], (err, result) => {
      if (err) {
        console.log(err);
      } else {
        res.send(result);
      }
    })
  })



//   **********************Search User**************************


app.get("/search/:email/:password",(req,res)=>{
    const uemail = req.params.email;
    const upass = req.params.password;
    con.query("select * from userReg where Email = ? and Password = ? ",[uemail,upass],(err, result) => {
        if (err) {
          console.log(err);
        } else {
          res.send(result);
        }
      })
    })



app.listen(5000);

// insert into addCar values(?,?,?,?,?,?,?,?,?,?,?,?)', [id,brand, rating, carName, imgUrl,model,price,speed,gps,seatType,auto,decription]