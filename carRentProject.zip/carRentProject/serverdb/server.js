// const express=require('express');
const mysql=require('mysql')
// const app=express();
// const cors=require('cors');
// app.use(cors());
// app.use(express.json());

const con=mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "password",
    database: "car"
});


con.connect(function(err) {
    if (err) throw err;
     con.query("select * from userReg",function(err,result){
      if(err)throw err;
      console.log("all result are here 1",result)
     })
  });
  module.exports=con;


// con.connect((error)=>{
//     if(error)
//         console.log("Database Not  Connected..",error);
//     else
//         console.log("Database Connected..")
// });


// module.exports =con;